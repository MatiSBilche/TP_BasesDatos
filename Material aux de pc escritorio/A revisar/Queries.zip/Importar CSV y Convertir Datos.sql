USE TPBaseDeDatos
BULK INSERT datos_staging
FROM 'C:\Users\Black\Desktop\Tp Data BAse\datos2023.csv'
WITH
(
FIRSTROW = 2,
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n',
FORMAT = 'CSV',
CODEPAGE = '65001'
);

UPDATE datos_staging
SET [nombre] = replace(replace(replace([nombre],' ','<>'),'><',''),'<>',' ')

UPDATE datos_staging
SET [nombre] = LTRIM(RTRIM([nombre]))

UPDATE datos_staging
SET equipoOP_ciudad = LTRIM(RTRIM(equipoOP_ciudad))

UPDATE datos_staging
SET [equipoOP_ciudad] = replace(replace(replace([equipoOP_ciudad],' ','<>'),'><',''),'<>',' ')

UPDATE datos_staging
SET [equipoOP_ciudad] = LTRIM(RTRIM([equipoOP_ciudad]))



UPDATE datos_staging
SET [stat_tiros_triples_convertidos_nombre] = replace([stat_tiros_triples_convertidos_nombre], '  ', ' ')

UPDATE datos_staging
SET [stat_tiros_triples_convertidos_nombre] = LTRIM(RTRIM([stat_tiros_triples_convertidos_nombre]))




-- Actualiza las alturas en pies a metros
UPDATE datos_staging_respaldo
SET altura = CAST(REPLACE(altura, '-', '.') * 0.3048 AS FLOAT)
WHERE CHARINDEX('-', altura) > 0;

BEGIN TRANSACTION
UPDATE datos_staging
SET altura = 
    CASE 
        WHEN CHARINDEX('-', altura) > 0 THEN
            -- Convierte de pies a metros
            CAST(REPLACE(altura, '-', '.') AS DECIMAL(5, 2)) * 0.3048
        ELSE
            -- Ya est� en metros; redondea al formato DECIMAL(5,2)
            CAST(altura AS DECIMAL(5, 2))
    END;
COMMIT


-- Actualiza el peso
BEGIN TRANSACTION
UPDATE datos_staging
SET peso = 
    CASE 
        WHEN CHARINDEX('libras', peso) > 0 THEN
            CAST(REPLACE(peso, ' libras', '') AS DECIMAL(5, 2)) / 2.205
        ELSE
            CAST(REPLACE(peso, ' kilogramos', '') AS DECIMAL(5, 2))
    END;
COMMIT


DECLARE @valueToConvert VARCHAR(50);
SET @valueToConvert='6-8';
SELECT CAST(REPLACE(@valueToConvert, '-', '.') AS NUMERIC(10,2)) * 0.3048 as ConvertedNumber;
GO

